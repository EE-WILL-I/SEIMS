create
    definer = root@localhost procedure randomize_oo1(IN org int)
begin
	call clean_oo1 (org);
	call generate_oo1_vr2_all (org);
END;

