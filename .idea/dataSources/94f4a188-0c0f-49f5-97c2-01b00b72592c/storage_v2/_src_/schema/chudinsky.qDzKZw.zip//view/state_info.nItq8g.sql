create definer = root@localhost view state_info as
select sum(`ov5`.`val_r2_1`) AS `studentsNum`
from ((`chudinsky`.`region` `r` join `chudinsky`.`build` `b`
       on ((`b`.`id_region` = `r`.`id`))) join `chudinsky`.`oo1_vrr5` `ov5` on ((`ov5`.`id_build` = `b`.`id`)))
where (`ov5`.`id_r1` = 9);

