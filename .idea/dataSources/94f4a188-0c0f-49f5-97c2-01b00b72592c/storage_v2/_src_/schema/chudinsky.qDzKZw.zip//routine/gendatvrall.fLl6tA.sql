create
    definer = root@localhost procedure gendatvrall(IN org int)
begin
    call gendatvr1(org);
    call gendatvr2(org);
    call gendatvr3(org);
    call gendatvr4(org);
    call gendatvr5(org);
    call gendatvr6(org);
    call gendatvr7(org);
    call gendatvr8(org);
    call gendatvr9(org);
    call gendatvr10(org);
    call gendatvr11(org);
    call gendatvr12(org);
    call gendatvr13(org);
    call gendatvr14(org);
    call gendatvr15(org);
end;

