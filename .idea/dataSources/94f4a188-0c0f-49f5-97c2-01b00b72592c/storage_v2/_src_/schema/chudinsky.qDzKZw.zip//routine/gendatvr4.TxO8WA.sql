create
    definer = root@localhost procedure gendatvr4(IN org int)
begin
    declare r1 int default 1;
    declare r1l int;
    declare r2 int default 1;
    declare r2l int;
    select count(id) into r1l from doo_r4_1;
    select count(id) into r2l from doo_r4_2;
    while (r1 <= r1l) DO
            while (r2 <= r2l) DO
                    insert into doo_vr4 (id_buildokud, id_R4_1, id_R4_2, value) values (org, r1, r2, 0);
                    set r2 = r2 + 1;
                end while;
            set r2 = 1;
            set r1 = r1 + 1;
        end while;
end;

