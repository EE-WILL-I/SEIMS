create
    definer = root@localhost procedure generate_oo1_vr2(IN org int, IN vr int, IN ut int)
begin
	set @r1_len = 1;
	set @t = concat('oo1_vrr', vr);
	set @m = concat('select r1_name into @r1 from vr_update_type_mapping where vr_name like "',@t,'"');
	
	prepare r1 from @m;
	execute r1;
	DEALLOCATE prepare r1;
	
	if(@r1 is null) then
		if(ut = 1) then
			set @t = concat('oo1_r', vr, '_1');
		else
			set @t = concat('oo1_r', vr);
		end if;
	else
		set @t = @r1;
	end if;
	
	set @id = 1;
	set @c = concat('select count(id) into @r1_len from ', @t);
	prepare num_r1 from @c;
	execute num_r1;
	DEALLOCATE prepare num_r1;
	
	set @t2 = concat('oo1_vrr', vr);
	set @m = concat('select r2_name into @r2 from vr_update_type_mapping where vr_name like "',@t2,'"');
	
	prepare r2 from @m;
	execute r2;
	DEALLOCATE prepare r2;
	
	if(@r2 is null) then
		if(ut = 1) then
			set @t2 = concat('oo1_r', vr, '_2');
		else
			set @t2 = concat('oo1_r', vr);
		end if;
	else
		set @t2 = @r2;
	end if;
	set @cc = 1;
	set @l = concat('SELECT count(id) into @cc FROM ',@t2);
	prepare num_r2 from @l;
	execute num_r2;
	DEALLOCATE prepare num_r2;
    
	set @n = concat(',', CEIL(RAND() * (100)));
	if(ut = 1) then
		while (@id < @cc) DO
			set @n = concat(@n, ',', CEIL(RAND() * (100))); 
			set @id = @id + 1;
		end while;
	end if;
	
	set @id = 1;
	set @t = concat('oo1_vrr', vr);
	set @q = concat('insert into ', @t, ' values (', org, ',', @id ,@n, ')');
	
    while (@id < @r1_len) DO
    	set @id = @id + 1;
    	set @n = concat(',', CEIL(RAND() * (100)));
    	set @i = 1;
    	if(ut = 1) then
			while (@i < @cc) DO
				set @n = concat(@n, ',', CEIL(RAND() * (100))); 
				set @i = @i + 1;
			end while;
		end if;
        set @q = concat(@q, ',(',org,',',@id,@n,')');
    end while;
    
    prepare gen_vr2 from @q;
	execute gen_vr2;
	DEALLOCATE prepare gen_vr2;
    select @q;
END;

