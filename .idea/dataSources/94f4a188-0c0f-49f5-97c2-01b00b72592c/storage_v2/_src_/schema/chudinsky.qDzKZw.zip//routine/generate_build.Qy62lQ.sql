create
    definer = root@localhost procedure generate_build()
begin
	set @m = concat('select o.id into @r1 from vr_update_type_mapping where vr_name like "',@t,'"');
	
	prepare r1 from @m;
	execute r1;
	DEALLOCATE prepare r1;
	
	if(@r1 is null) then
		if(ut = 1) then
			set @t = concat('oo1_r', vr, '_1');
		else
			set @t = concat('oo1_r', vr);
		end if;
	else
		set @t = @r1;
	end if;
END;

