create
    definer = root@localhost procedure gendatvr8(IN org int)
begin
    declare r1 int default 1;
    declare r1l int;
    declare r2 int default 1;
    declare r2l int;
    select count(id) into r1l from doo_r7_1;
    select count(id) into r2l from doo_r8;
    while (r1 <= r1l) DO
            while (r2 <= r2l) DO
                    insert into doo_vr8 (id_buildokud, id_R7_1, id_R8, value) values (org, r1, r2, 0);
                    set r2 = r2 + 1;
                end while;
            set r2 = 1;
            set r1 = r1 + 1;
        end while;
end;

