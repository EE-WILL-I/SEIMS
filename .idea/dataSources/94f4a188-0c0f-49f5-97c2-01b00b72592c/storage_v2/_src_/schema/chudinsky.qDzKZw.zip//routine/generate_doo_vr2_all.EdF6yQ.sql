create
    definer = root@localhost procedure generate_doo_vr2_all(IN org int)
begin
	call generate_vr2(org, 1, 2);
	call generate_vr2(org, 2, 2);
	call generate_vr2(org, 3, 1);
	call generate_vr2(org, 3, 1);
	call generate_vr2(org, 4, 1);
	call generate_vr2(org, 5, 2);
	call generate_vr2(org, 6, 2);
	call generate_vr2(org, 7, 1);
	call generate_vr2(org, 8, 2);
	call generate_vr2(org, 9, 1);
	call generate_vr2(org, 10, 1);
	call generate_vr2(org, 11, 2);
	call generate_vr2(org, 12, 2);
	call generate_vr2(org, 13, 2);
	call generate_vr2(org, 14, 2);
	call generate_vr2(org, 15, 2);
	call generate_vr2(org, 16, 2);
	call generate_vr2(org, 17, 2);
END;

