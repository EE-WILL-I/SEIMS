create
    definer = root@localhost procedure gendat1()
begin
    declare i int default 1;
    declare idbo int;
    declare len int default 0;
    declare idokud int;
    select min(id) into i from build;
    set idbo = 2;
    select max(id) into len from build;
    while (i <= len) DO
        select o.id into idokud from okud o join build b on b.id_type = o.id_type_build where b.id = i;
        insert into buildokud values (idbo, i, idokud, current_date());
        set i = i+1;
        set idbo = idbo+1;
    end while;
end;

