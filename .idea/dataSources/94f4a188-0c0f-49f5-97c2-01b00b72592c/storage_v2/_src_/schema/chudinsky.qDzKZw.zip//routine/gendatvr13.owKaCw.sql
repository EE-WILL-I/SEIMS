create
    definer = root@localhost procedure gendatvr13(IN org int)
begin
    declare i int default 1;
    declare len int default 0;
    set i = 1;
    select count(id) into len from doo_r13_1;
    while (i <= len) DO
            insert into doo_vr13_1 (id_buildokud, id_r13_1, value) values (org, i, 0);
            set i = i+1;
        end while;
    set i = 1;
    select count(id) into len from doo_r13_2;
    while (i <= len) DO
            insert into doo_vr13_2 (id_buildokud, id_r13_2, value) values (org, i, 0);
            set i = i+1;
        end while;
end;

