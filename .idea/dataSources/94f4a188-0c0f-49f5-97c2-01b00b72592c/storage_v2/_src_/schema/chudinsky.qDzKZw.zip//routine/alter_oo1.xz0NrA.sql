create
    definer = root@localhost procedure alter_oo1()
begin
		declare r1 int;
		set @id0 = 20;
		select count(*) into r1 from vr_update_type_mapping where vr_type_id = 2;
		while(@id0 <= r1) do
			set @t = concat('ALTER TABLE chudinsky.oo1_vrr',@id0,' ADD CONSTRAINT oo1_vrr',@id0,'_pk PRIMARY KEY (id_build,id_r1)');
			prepare r1 from @t;
			execute r1;
			DEALLOCATE prepare r1;
			set @id0 = @id0 + 1;
		end while;
END;

