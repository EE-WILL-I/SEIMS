create
    definer = root@localhost procedure gendatvr3(IN org int)
begin
    declare r1 int default 1;
    declare r1l int;
    declare r2 int default 1;
    declare r2l int;
    select count(id) into r1l from doo_r3_1;
    select count(id) into r2l from doo_r3_2;
    while (r1 <= r1l) DO
        if(r1 = 21 or r1 = 22 or r1 = 23) then
            insert into doo_vr3 (id_buildokud, id_R3_1, id_R3_2, value) values (org, r1, 1, 0);
            insert into doo_vr3 (id_buildokud, id_R3_1, id_R3_2, value) values (org, r1, 5, 0);
        else
            while (r2 <= r2l) DO
                insert into doo_vr3 (id_buildokud, id_R3_1, id_R3_2, value) values (org, r1, r2, 0);
                set r2 = r2 + 1;
            end while;
        end if;
        set r2 = 1;
        set r1 = r1 + 1;
    end while;
end;

