create
    definer = root@localhost procedure gendatvr11(IN org int)
begin
    declare i int default 1;
    declare len int default 0;
    set i = 1;
    select count(id) into len from doo_r11;
    while (i <= len) DO
            insert into doo_vr11 (id_buildokud, id_r11, value) values (org, i, 0);
            set i = i+1;
        end while;
end;

