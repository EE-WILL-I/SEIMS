create
    definer = root@localhost procedure reset_oo1(IN org int)
begin
	call clean_oo1(org);
	call copy_for_oo1 (org);
END;

