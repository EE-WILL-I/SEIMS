create
    definer = root@localhost procedure copy_for_oo1(IN org int)
begin
	declare r1 int;
	declare gen tinyint;

	DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

   	start transaction;
	set gen := (select `generated` from build_db_info where id = org);
	if(gen is null) then
		insert into build_db_info values (org, 0, CURRENT_TIMESTAMP, null);
		set gen = 0;
	end if;
	if(gen <> 1) then
		set @id0 = 1;
		select count(*) into r1 from vr_update_type_mapping where vr_type_id = 2;
		while(@id0 <= r1) do
			set @vr = concat('oo1_vrr', @id0);
			call copy_template_for (@vr, org);
			set @id0 = @id0 + 1;
		end while;
		update build_db_info set `generated` = 1 where id = org;
		update build_db_info set upd_date  = CURRENT_TIMESTAMP where id = org;
	end if;

	commit;
END;

