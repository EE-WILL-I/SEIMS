create
    definer = root@localhost procedure copy_for_oo1(IN org int)
begin
	set @id0 = 1;
	set @len = 33;
	while(@id0 <= @len) do
		set @vr = concat('oo1_vrr', @id0);
		call copy_template_for (@vr, org);
		set @id0 = @id0 + 1;
	end while;
END;

