create
    definer = root@localhost procedure gendatvr2(IN org int)
begin
    declare i int default 1;
    declare len int default 0;
    set i = 1;
    select count(id) into len from doo_r2;
    while (i <= len) DO
            insert into doo_vr2 (id_buildokud, id_r2, value) values (org, i, 'Нет таблицы кодов');
            set i = i+1;
        end while;
end;

