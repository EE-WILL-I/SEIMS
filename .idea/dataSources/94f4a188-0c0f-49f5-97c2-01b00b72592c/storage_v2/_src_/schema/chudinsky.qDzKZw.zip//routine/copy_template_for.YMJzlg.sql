create
    definer = root@localhost procedure copy_template_for(IN vrr varchar(20), IN org int)
begin
	set @q1 = 'DROP TEMPORARY table IF EXISTS temp_table;';
	set @q2 = concat('CREATE TEMPORARY TABLE temp_table AS SELECT * FROM ', vrr, ' WHERE id_build=0;');
	set @q3 = concat('UPDATE temp_table SET id_build = ', org, ';');
	set @q4 = concat('INSERT INTO ', vrr, ' SELECT * FROM temp_table;');
    set @q5 = 'DROP TEMPORARY TABLE temp_table;';
	prepare r1 from @q1;
	execute r1;
	prepare r1 from @q2;
	execute r1;
	prepare r1 from @q3;
	execute r1;
	prepare r1 from @q4;
	execute r1;
	prepare r1 from @q5;
	execute r1;
	DEALLOCATE prepare r1;
END;

