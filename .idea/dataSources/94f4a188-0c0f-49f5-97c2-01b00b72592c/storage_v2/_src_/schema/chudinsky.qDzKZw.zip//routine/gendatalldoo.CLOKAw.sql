create
    definer = root@localhost procedure gendatalldoo(IN startid int)
begin
    declare i int;
    declare len int;
    declare orgtype int;
    set i = startid;
    select max(id) into len from buildokud;
    while (i <= len) DO
        select id_type into orgtype from build join buildokud b on build.id = b.id_build where b.id = i;
        if(orgtype = 2) then
            call gendatvrall(i);
            select  concat ('Generated org: ', i) as 'info';
        end if;
        set i = i + 1;
        end while;
end;

