create
    definer = root@localhost procedure create_oo1_vr2(IN vr int, IN ut int)
begin
	set @r2_name = "";
	set @r2_len = 1;
	set @r2 = "";
	set @t = concat('oo1_vrr', vr);
	set @m = concat('select r2_name into @r2 from vr_update_type_mapping where vr_name like "',@t,'"');
	
	prepare r2 from @m;
	execute r2;
	DEALLOCATE prepare r2;
	
	if(@r2 is null) then
		if(ut = 1) then
			set @t = concat('oo1_r', vr, '_2');
		else
			set @t = concat('oo1_r', vr);
		end if;
	else
		set @t = @r2;
	end if;
	
	set @q1 = concat('select name into @r2_name from ', @t, ' where id = ');
	set @id = 1;
	
	set @c = concat('select count(name) into @r2_len from ', @t);
	prepare num_r2 from @c;
	execute num_r2;
	DEALLOCATE prepare num_r2;
	
	set @cvr2 = concat('CREATE TABLE oo1_vrr', vr);
	set @cvr2 = concat(@cvr2, ' (`id_build` int(11) NOT NULL, `id_r1` int(11) NOT NULL');
	
	if(ut = 1) then
		while(@id <= @r2_len) DO
			set @q2 = concat(@q1, @id);
		    prepare lbl_r2 from @q2;
		    execute lbl_r2;
		    
		    set @cvr2 = concat(@cvr2, ', `');
		    set @c = concat('val_r2_',@id, '` int(11) null');
		    set @cvr2 = concat(@cvr2, @c);
		    
		    DEALLOCATE prepare lbl_r2;
		    set @id = @id + 1;
	    end while;
    else
    	set @cvr2 = concat(@cvr2, ', `');
		set @c = concat('val_r2_1` int(11) null');
		set @cvr2 = concat(@cvr2, @c);
    end if;
    
    set @cvr2 = concat(@cvr2, ') DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;');
    prepare crt_vr2 from @cvr2;
    execute crt_vr2;
end;

