create
    definer = root@localhost procedure transorg()
begin
    declare distr int;
    declare orgtype int;
    declare orgtypename varchar(100);
    declare distrname varchar(100);
    declare orgname varchar(500);
    declare i int;
    declare orglen int;
    set i = 2610;
    select max(id) into orglen from organizations;
    while (i < orglen) DO
        select name into orgname from organizations where id = i;
        select district into distrname from organizations where id = i;
        select id into distr from region where name like distrname;
        select type into orgtypename from organizations where id = i;
        select id into orgtype from type_build where name like orgtypename;
        insert into build values (i, orgtype, distr, orgname, null, null, null, null, null, null);
        set i = i + 1;
    end while;
end;

