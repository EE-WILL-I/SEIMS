create
    definer = root@localhost procedure generate_oo1_vr2_all(IN org int)
begin
	declare gen tinyint;

	DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
   
   	start transaction;
	set gen := (select `generated` from build_db_info where id = org);

	if(gen is null) then
		insert into build_db_info values (org, 0, CURRENT_TIMESTAMP, null);
		set gen = 0;
	end if;
	
	if(gen <> 1) then
		call generate_oo1_vr2(org, 1, 2);
		call generate_oo1_vr2(org, 2, 2);
		set @id0 = 3;
		set @len = 0;
		set @l = concat('select count(id) into @len from vr_update_type_mapping where vr_type_id = 2');
		prepare r1 from @l;
		execute r1;
		DEALLOCATE prepare r1;
		while(@id0 <= @len) do
			call generate_oo1_vr2(org, @id0, 1);
			set @id0 = @id0 + 1;
		end while;
		update build_db_info set `generated` = 1 where id = org;
	end if;
	commit;
END;

