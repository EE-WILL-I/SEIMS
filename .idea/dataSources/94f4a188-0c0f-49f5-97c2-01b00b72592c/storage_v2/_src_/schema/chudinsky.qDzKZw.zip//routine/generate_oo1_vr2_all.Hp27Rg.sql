create
    definer = root@localhost procedure generate_oo1_vr2_all(IN org int)
begin
	call generate_oo1_vr2(org, 1, 2);
	call generate_oo1_vr2(org, 2, 2);
	set @id0 = 3;
	set @len = 33;
	while(@id0 <= @len) do
		call generate_oo1_vr2(org, @id0, 1);
		set @id0 = @id0 + 1;
	end while;
END;

