create
    definer = root@localhost procedure alter_oo1(IN vr int, IN ut int)
begin
	set @t = concat('truncate chudinsky.oo1_vrr',vr);
	prepare r1 from @t;
	execute r1;
	DEALLOCATE prepare r1;
	set @t = concat('ALTER TABLE chudinsky.oo1_vrr',vr,' CHANGE id_buildokud id_build int NOT NULL');
	prepare r1 from @t;
	execute r1;
	DEALLOCATE prepare r1;
	set @t = concat('ALTER TABLE chudinsky.oo1_vrr',vr,' ADD CONSTRAINT oo1_vrr',vr,'_build_fk FOREIGN KEY (id_build) REFERENCES chudinsky.build(id) ON DELETE CASCADE ON UPDATE CASCADE');
	prepare r1 from @t;
	execute r1;
	DEALLOCATE prepare r1;
END;

